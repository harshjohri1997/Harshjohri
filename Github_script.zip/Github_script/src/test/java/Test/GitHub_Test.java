package Test;

import org.testng.annotations.Test;

import Pages.GitHub_page;

public class GitHub_Test 
{

	GitHub_page object = new GitHub_page();
	
	@Test(priority = 1, enabled = true)
	public void getbrowserLaunch()
	{
		try 
		{
			object.GetBrowserLaunch();
		} catch (Exception e)
		{
			System.out.println("Issue in GetbrowserLaunch Method "+e);
		}
	}
	@Test(priority = 2, enabled = true)
	public void GetLogin_GitHub()
	{
		try 
		{
			object.Login_GitHub();
		} catch (Exception e)
		{
			System.out.println("Issue in GetLogin_GitHub method "+e);
		}
	}
	
	@Test(priority = 3, enabled = true)
	public void Repositry_Creation()
	{
		try 
		{
			object.repositryCreation();	
		} catch (Exception e) 
		{
			System.out.println("Issue in repositryCreation Method "+e);
		}
	}
	
	@Test(priority = 4, enabled = true)
	public void CreateNewIssue()
	{
		try 
		{
			object.IssueCreation();
		} catch (Exception e) 
		{
			System.out.println("Issue in Create New Issue Method "+e);
		}
	}
	@Test(priority = 5, enabled = true)
	public void CraeteAnotherIssue()
	{
		try 
		{
			object.CreateAnotherIssue();
		} catch (Exception e) 
		{
			System.out.println("Issye in CreateAnother Issue Method "+e);
		}
	}
	
	@Test(priority = 6 , enabled = true)
	public void Addcomments()
	{
		try 
		{
			object.AddComments();	
		} catch (Exception e)
		{
			System.out.println("Issue in Add comments method "+e);
		}
	}
	
	@Test(priority = 7 , enabled = true)
	public void AddmentionedIssue()
	{
		try 
		{
			object.IssueMentioned();	
		} catch (Exception e) 
		{
			System.out.println("Issue in AddMentioned Issue method "+e);
		}
	}
	
	@Test(priority = 8, enabled = true)
	public void DeleteRepositry()
	{
		try 
		{
		object.Deletetherepositry();	
		} catch (Exception e)
		{
			System.out.println("issue in DeleteRepositry method "+e);
		}
	}
	
	
}
