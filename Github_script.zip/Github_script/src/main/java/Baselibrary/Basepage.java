package Baselibrary;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Basepage
{
	
	static public WebDriver driver=new ChromeDriver();
	
	public static void LaunchUrl(String URl)
	{
		driver.navigate().to(URl);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
}
