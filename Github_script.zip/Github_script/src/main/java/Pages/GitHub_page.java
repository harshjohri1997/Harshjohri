package Pages;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Baselibrary.Basepage;

public class GitHub_page extends Basepage
{
	
   public GitHub_page()
   {
	   PageFactory.initElements(driver, this);
   }
   static WebDriverWait wait;
 
	@FindBy(xpath="//*[@id='login_field']")
	private WebElement usernametextbox;
	@FindBy(xpath="//*[@id='password']")
	private WebElement Password;
	@FindBy(xpath="//*[@id='login']/form/div[4]/input[9]")
	private WebElement signin;
	@FindBy(xpath = "//*[@data-ga-click='(Logged out) Header, clicked Sign in, text:sign-in']")
	private WebElement SigninBtn;
	@FindBy(xpath="//*[@id='repos-container']/h2/a[1]")
	private WebElement NewRepositry;
	@FindBy(xpath="//*[@id='repository_name']")
	private WebElement Repositrytxtbox;
	@FindBy(xpath="//*[@class='btn btn-primary first-in-line']")
	private WebElement Createrepositrybtn;
	@FindBy(xpath="//*[@id='js-repo-pjax-container']/div[2]/nav/ul/li[2]/a/span")
	private WebElement IssueBtn;	
	@FindBy(xpath="//*[text()='New issue']")
	private WebElement NewIssuebtn;
	@FindBy(xpath="//*[@id='issue_title']")
	private WebElement titletextbox;
	@FindBy(xpath="//*[@id='issue_body']")
	private WebElement bodytextbox;
	@FindBy(xpath="//*[@id='new_issue']/div/div/div[1]/div/div[1]/div[2]/button")
	private WebElement SubmitNewissue;
	@FindBy(xpath="//*[@id='partial-discussion-header']/div[1]/div/div/a")
	private WebElement SecondNewIssue;
	@FindBy(xpath="//*[@id='issue_1_link']")
	private WebElement FirstIssueLink;
	@FindBy(xpath="//*[@id='issue_2_link']")
	private WebElement SecondIssueLink;
	@FindBy(xpath="//*[@id='new_comment_field']")
	private WebElement commenttextbox;
	@FindBy(xpath="//*[@id='partial-new-comment-form-actions']/div/div[2]/button")
	private WebElement Commentbtn;
	@FindBy(xpath="//*[@id='js-repo-pjax-container']/div[2]/nav/ul/li[9]/a")
	private WebElement SettingIcon;
	@FindBy(xpath="//*[@id='options_bucket']/div[9]/ul/li[4]/details/summary")
	private WebElement DeleteRepositry;
	@FindBy(xpath="//*[@id='options_bucket']/div[9]/ul/li[4]/details/details-dialog/div[3]/form/p/input")
	private WebElement Deletetxtbox;
	@FindBy(xpath="//*[@id='options_bucket']/div[9]/ul/li[4]/details/details-dialog/div[3]/form/button")
	private WebElement Finaldelete;
	
	String repositryname=null;
	public static void Inner_scrolltoptobottom(WebDriver driver,WebElement ele ) {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollTop = arguments[1];", ele, 500);
		} catch (Exception ex) {
			System.out.println("Exception in inner scroll.");
		}

	}
	
	public void GetBrowserLaunch()
	{
		try 
		{
			LaunchUrl("https://github.com/");
			driver.manage().window().maximize();
		
		} catch (Exception e) 
		{
			System.out.println("Issue in GetBrowserLaunch method "+e);
		}
	}
	
	public void Login_GitHub()
	{
		try
		{
			wait = new WebDriverWait(driver, 2000);
			wait.until(ExpectedConditions.elementToBeClickable(SigninBtn));
			SigninBtn.click();
			Thread.sleep(3000);
			usernametextbox.sendKeys("harshjohri.hj@gmail.com");
			Thread.sleep(2000);
			Password.sendKeys("Harsh@#1997");
			Thread.sleep(2000);
			signin.click();
		} catch (Exception e) 
		{
			System.out.println("Issue in Login_GitHub method "+e);
		}
	}
	
	public void repositryCreation()
	{
		try 
		{
			Thread.sleep(3000);
			
			((JavascriptExecutor) driver).executeScript("window.open('about:blank','_blank');");
			ArrayList<String> tab = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tab.get(1));
			
			driver.get("https://github.com/new ");
			
			/* NewRepositry.click(); */
			Thread.sleep(3000);
			long time = System.currentTimeMillis();
			repositryname = "TestAutomationLocofast"+time;
			Repositrytxtbox.sendKeys(repositryname);
			Thread.sleep(3000);
			Createrepositrybtn.click();
		} catch (Exception e) 
		{
			System.out.println("Issue in repositryCreation Method "+e);
		}
	}
	// challenge 2
	public void IssueCreation()
	{
		try 
		{
			IssueBtn.click();
			Thread.sleep(4000);
			NewIssuebtn.click();
			Thread.sleep(3000);
			titletextbox.sendKeys("Forget password functionality is not working");
			Thread.sleep(3000);
			bodytextbox.sendKeys("After enter Mobile no Password is not recieved to User");
			Thread.sleep(3000);
			SubmitNewissue.click();
			
		} catch (Exception e) 
		{
			System.out.println("Issue in IssueCreation Method");
		}
	}
	
	public void CreateAnotherIssue()
	{
		try 
		{
			Thread.sleep(3000);
			SecondNewIssue.click();
			Thread.sleep(3000);
			titletextbox.sendKeys("OTP text box is not display in Forget password  -related to Issue #1(Forget password functionality is not working)");
			Thread.sleep(3000);
			bodytextbox.sendKeys("After Recieve OTP to User , there is not display OTPText box -related to Issue #1(Forget password functionality is not working)");
			Thread.sleep(3000);
			SubmitNewissue.click();
		} catch (Exception e)
		{
			System.out.println("Issue in CreateAnotherIssue Method");
		}
	}
	
	
	public void AddComments()
	{
		try 
		{
			Thread.sleep(3000);
			FirstIssueLink.click();
			Thread.sleep(3000);
			Inner_scrolltoptobottom(driver, commenttextbox);
			commenttextbox.sendKeys("Ok I will check and Update You");
			
		} catch (Exception e)
		{
		
		}
	}
	
	public void IssueMentioned()
	{
		try 
		{	Thread.sleep(3000);
			commenttextbox.sendKeys("Ok #2 issue related to this issue");
			Thread.sleep(3000);
			Commentbtn.click();
			Thread.sleep(3000);
		} catch (Exception e) 
		{
			System.out.println("issue in issue Mentioned Method "+e);
		}
	}
	
	public void Deletetherepositry()
	{
		try 
		{
			Thread.sleep(3000);
			SettingIcon.click();
			Thread.sleep(3000);
			DeleteRepositry.click();
			Thread.sleep(3000);
			Deletetxtbox.sendKeys("harshjohri1997/"+repositryname);
			Thread.sleep(3000);
			Finaldelete.click();
		} catch (Exception e) 
		{
			System.out.println("Issue in Deletetherepositry method"+e);
		}
	}
	
}
